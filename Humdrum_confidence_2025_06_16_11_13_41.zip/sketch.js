

let caminhaoX = -100; let semaforoVerde = true; let frameParado = 0;

let passarosRural = []; let passarosUrbano = [];

function setup() { createCanvas(1000, 600); angleMode(DEGREES);

for (let i = 0; i < 4; i++) { passarosRural.push({ x: 50 + i * 50, y: 120, flap: random(360) }); passarosUrbano.push({ x: 600 + i * 50, y: 100, flap: random(360) }); } }

function draw() { background(135, 206, 235);

desenharSol(); desenharCenario(); desenharCaminhao(); desenharMensagens(); }

function desenharSol() { push(); translate(100, 100); fill(255, 204, 0); ellipse(0, 0, 80, 80); stroke(255, 204, 0); strokeWeight(3); for (let i = 0; i < 360; i += 30) { let x1 = cos(i + frameCount) * 50; let y1 = sin(i + frameCount) * 50; let x2 = cos(i + frameCount) * 70; let y2 = sin(i + frameCount) * 70; line(x1, y1, x2, y2); } pop(); }

function desenharMensagens() { fill(0); textSize(18); textAlign(CENTER);

if (caminhaoX > 250 && caminhaoX < 730) { text( "Caminhão saiu da zona rural levando alimentos", width / 4, 50 ); }

if (caminhaoX >= 730 && caminhaoX <= 770) { text( "O caminhão chegou ao mercado!", (3 * width) / 4, 50 ); } }

function desenharCenario() { stroke(0); strokeWeight(4); line(width / 2, 0, width / 2, height); noStroke();

fill(34, 139, 34); rect(0, 480, width / 2, 120); fill(100, 200, 100); rect(width / 2, 480, width / 2, 120);

desenharPassaros(); desenharNuvens(200); // ajustado para liberar o sol desenharNuvens(700);

desenharEstradaUrban(); desenharPredios(); desenharMercado(); desenharSemaforo();

desenharEstradaRural(); desenharCasaRural(); desenharTrator(); desenharAnimais(); desenharHomemECachorro(); }

function desenharNuvens(x) { fill(255); ellipse(x, 100, 100, 60); ellipse(x + 40, 100, 80, 50); ellipse(x - 40, 100, 80, 50); }

function desenharPassaros() { for (let p of passarosRural) { desenharPassaroAnimado(p); p.x += 1; if (p.x > width / 2) p.x = -30; p.flap += 5; } for (let p of passarosUrbano) { desenharPassaroAnimado(p); p.x -= 1.5; if (p.x < width / 2) p.x = width + 30; p.flap += 5; } }

function desenharPassaroAnimado(p) { push(); translate(p.x, p.y); let flap = sin(p.flap) * 5;

fill(80); ellipse(0, 0, 30, 20); ellipse(-12, -2, 10, 10); // cabeça

fill(255, 165, 0); triangle(-17, -2, -22, -4, -22, 0); // bico

fill(120); beginShape(); vertex(0, 0); vertex(10, -10 - flap); vertex(20, -5 - flap); vertex(15, 0); endShape(CLOSE);

beginShape(); vertex(0, 0); vertex(-10, -10 - flap); vertex(-20, -5 - flap); vertex(-15, 0); endShape(CLOSE); pop(); }

function desenharEstradaUrban() { fill(50); rect(500, 400, 500, 80); for (let i = 0; i < 10; i++) { fill(255); rect(520 + i * 50, 435, 30, 10); } }

function desenharMercado() { fill(200, 0, 0); rect(700, 250, 200, 150); fill(255); textSize(24); text("MERCADO", 800, 280); fill(240); rect(730, 300, 40, 60); rect(790, 300, 40, 60); fill(100); rect(765, 360, 40, 40); }

function desenharPredios() { fill(100); rect(600, 180, 60, 220); rect(870, 200, 50, 200); fill(255); for (let y = 190; y < 380; y += 30) { rect(610, y, 15, 15); rect(630, y, 15, 15); rect(880, y, 10, 10); rect(900, y, 10, 10); } }

function desenharSemaforo() { fill(0); rect(670, 310, 20, 100); fill(50); rect(665, 310, 30, 80); fill('red'); ellipse(680, 320, 15); fill('yellow'); ellipse(680, 350, 15); fill(semaforoVerde ? 'green' : 'gray'); ellipse(680, 380, 15); }

function desenharEstradaRural() { fill(60); rect(0, 400, 500, 80); for (let i = 0; i < 10; i++) { fill(255); rect(20 + i * 50, 435, 30, 10); } }

function desenharCasaRural() { fill(210, 180, 140); rect(100, 300, 120, 100); fill(150, 75, 0); triangle(90, 300, 160, 240, 230, 300); fill(255); rect(130, 330, 30, 30); fill(100); rect(180, 340, 25, 60); }

function desenharTrator() { fill(255, 0, 0); rect(300, 360, 60, 30); fill(0, 0, 255); rect(315, 340, 30, 20); fill(0); ellipse(310, 390, 20); ellipse(350, 390, 30); }

function desenharAnimais() { fill(255); rect(80, 480, 60, 30); fill(0); ellipse(90, 490, 8); ellipse(110, 495, 8); fill(150); ellipse(135, 490, 20, 20);

fill(165, 42, 42); rect(180, 470, 60, 25); ellipse(240, 470, 20, 20); fill(120, 60, 0); rect(175, 475, 5, 15); }

function desenharHomemECachorro() { fill(0, 0, 200); rect(350, 450, 20, 40); fill(255, 224, 189); ellipse(360, 440, 20); fill(0); ellipse(355, 438, 3); ellipse(365, 438, 3);

stroke(0); strokeWeight(3); line(350, 460, 340, 480); // braço esquerdo line(370, 460, 380, 480); // braço direito noStroke();

fill(139, 69, 19); ellipse(390, 480, 30, 20); ellipse(405, 480, 15, 15); fill(100); rect(395, 488, 5, 10); }

function desenharCaminhao() { if (caminhaoX < 730 || caminhaoX > 770) { caminhaoX += 2; frameParado = 0; } else if (frameParado < 180) { frameParado++; } else { caminhaoX += 2; }

fill(0, 128, 0); rect(caminhaoX, 370, 100, 40); fill(0, 100, 0); rect(caminhaoX + 70, 350, 30, 30); fill(0); ellipse(caminhaoX + 20, 410, 20); ellipse(caminhaoX + 80, 410, 20); }






